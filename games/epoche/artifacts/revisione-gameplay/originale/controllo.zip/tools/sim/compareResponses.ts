import { loadCampaignContent } from "@content/campaign/index";
import assert from "node:assert/strict";
import { runCampaign } from "./campaign";

const content = loadCampaignContent("rapid");
const strategies = process.argv.includes("--cautious")
  ? (["cautious"] as const)
  : (["first", "random"] as const);
for (let seed = 1; seed <= 25; seed++) {
  for (const route of [0, 1] as const) {
    for (const response of strategies) {
      const run = runCampaign(content, seed, "prudence", 25000, "rapid", {
        route,
        response,
        extended: false,
        withoutDeferredCosts: process.argv.includes("--no-deferred-costs"),
      });
      const arrival = run.arrived.find(campaign => campaign.core.eraId === "future");
      let control;
      if (arrival && process.argv.includes("--heritage")) {
        const replay = runCampaign(content, seed, "prudence", 25000, "rapid", {
          route, response, extended: false, withoutFutureHeritage: true,
        });
        assert.deepEqual(replay.arrived.find(campaign => campaign.core.eraId === "future"), arrival);
        assert.ok(replay.futureDecisions.every(decision => decision.used === null));
        control = {
          ending: replay.current.outcome?.kind ?? "open",
          ticks: replay.current.core.tick,
          population: replay.current.core.population,
        };
      }
      console.log(
        JSON.stringify({
          seed,
          route,
          response,
          ending: run.current.outcome?.kind ?? "open",
          era: run.current.core.eraId,
          ticks: run.current.core.tick,
          decisions: Object.values(run.encounters).reduce(
            (sum, era) => sum + era.ticks.length,
            0,
          ),
          ...(process.argv.includes("--heritage") ? {
            reachedFuture: !!arrival, inherited: arrival?.heritage ?? [],
            futureDecisions: run.futureDecisions, control: control ?? null,
          } : {}),
          choiceCounts: run.choiceCounts,
          affordableCounts: run.affordableCounts,
          delayedCollapse: run.delayedCollapse,
          cause: run.current.outcome?.kind === "collapse" ? {
            family: run.current.outcome.family,
            lastEntries: run.current.chronicle.slice(-12),
          } : null,
          firstUnavailable: run.firstUnavailable,
          setbacks: run.structural,
          population: run.current.core.population,
          peakCrisis: run.peakCrisis,
        }),
      );
    }
  }
}
